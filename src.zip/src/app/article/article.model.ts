let count: number= 0;
export class Article {

id:number;
votes: number;
title: string;
link: string;

  constructor( title: string, link: string,votes?:number) {
    this.id = count++;
    this.title =title;
    this.link =link;
    this.votes = votes||0;

  }
  voteUp():void{
    this.votes+=1;
  }

  voteDown():void{
    this.votes-=1;
  }

}
