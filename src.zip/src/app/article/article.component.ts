import { Component, Input, OnInit, Output } from '@angular/core';
import { Article } from './article.model';
import { AppComponent } from '../app.component';
import { EventEmitter } from  '@angular/core';


@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {
@Input()
article:Article= new Article('tmp','Link');
@Output()
deleteEvent= new EventEmitter<number>();

  constructor() {}

  voteUp():boolean{
    this.article.voteUp();
    return false;
  }
  voteDown():boolean{
    this.article.voteDown();
    return false;
  }
delete(id:number){
  this.deleteEvent.emit(id);
}





  ngOnInit(): void {
  }
}
