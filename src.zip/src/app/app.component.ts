import { HtmlParser } from '@angular/compiler';
import { Component,OnInit } from '@angular/core';
import { Article } from './article/article.model';
import { ArticleserviceService } from './articleservice.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'TP2reddit';
  articles:Article[]=[];

  constructor(private service:ArticleserviceService){


  }
  ngOnInit(): void {

    this.articles = this.service.getArticles();
  }
  addArticle(title : HTMLInputElement, link:HTMLInputElement){

    this.articles.push( new Article(title.value,link.value));
    title.value ='';
    link.value ='';
    return false;

  }
  supprimerArticle(id:number){
    let  index: number = this.articles.findIndex(article=> article.id==id);

       this.articles.splice(index, 1);
  return false;
  }
  sortedArticle():Article[]{
return this.articles.sort((a:Article, b:Article)=>b.votes - a.votes);
  }
}



